

ajax_data = {
  "ajax_url" : "http://macaobeachresort.com/wp-admin/admin-ajax.php",
}
